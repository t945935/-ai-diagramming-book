# 環境與可攜性

工作包不包含 node_modules、瀏覽器、字型、Java、Graphviz 或任何登入憑證。project/ 中的既有驗證文件可能記錄舊電腦絕對路徑；那是歷史證據，不是家裡可直接使用的路徑。

## 開始寫第一篇的最低需求

文字編輯器即可讀寫 Markdown。Python 3 可跑六個核心測試；Linux／WSL 有 make 時可用 make check-core。Git 用於建立真正 checkout 與提交，閱讀公開 Repo 不需要登入。

## 要重新渲染時才需要

既有驗證版本：Python 3.12.3、Node.js v24.21.0、npm 11.19.0、Mermaid CLI 11.17.0、D2 v0.9.0、PlantUML 1.2026.8、Temurin JRE 21.0.12.1+1、Graphviz dot 2.43.0。這是當時環境紀錄，不保證目前最新，也不表示家裡已安裝。

- Mermaid：依 package-lock.json 安裝套件，準備可信 Chromium。PUPPETEER_CONFIG 指向家裡的設定檔，勿抄舊路徑。
- Graphviz：安裝 dot，必要時以 DOT 指定執行檔。個人目錄解包的動態庫／外掛路徑不能跨機照抄。
- D2：本例使用 dagre，字型路徑需另設。
- PlantUML：Java、JAR 與 Noto 繁中字型另裝；本例用 headless 及 SANDBOX，未用外部 include。
- draw.io／Excalidraw：可用網頁開原生檔；新瀏覽器沒有舊工作階段，先保存自己的圖。

先看各範例 README／verification.md，再決定安裝步驟。本工作包沒有自動下載或安裝腳本，不會修改家裡的環境。

正常驗證需取消 BOOK_SOURCE_ROOT、REFUND_SCENARIOS 等故障注入覆寫。check-full 的十個測試不等於六工具全部渲染、GUI 或真實金流測試。

## Git 與授權

舊工作目錄原本不是 Git checkout，提交曾透過 API 完成。工作包使用遠端固定 commit 收錄，已驗證與 Git blob 一致；沒有把 API token 帶入包內。回家以 git clone 建立 checkout，不需沿用舊提交方法。

GitHub 寫入需要家裡自己的授權。使用憑證管理器／正式登入流程，不要把密碼、token 或一次性碼貼在聊天中。
