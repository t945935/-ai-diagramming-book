# 回家接續工作：先讀這份

專案：《讓 AI 畫對圖：六大繪圖工具的實作與協作》（暫名）
Repo：https://github.com/t945935/-ai-diagramming-book
工作包基準：5e1eb1addb738b70d2bc4093ae46de509ae9f5aa

這是開發交接快照，不是正式隨書 Release。project/ 收錄該 commit 的全部已提交專案檔案，沒有 Git 歷史或登入憑證。

## 目前做到哪裡

第 4 至 13 章都有樣章或短篇，其中 draw.io 第 8 章仍是短篇。六工具原始檔、預覽、提示詞、除錯範例、跨圖契約與部分退款案例已提交。

第 1 至 3 章尚未開始建立檔案；先前兩次「go」中斷，沒有留下半寫章節。下一步從第一篇開始，不需重做第 13 章或 GitHub 登入流程。

## 回家後最短路徑

1. 解壓縮工作包，閱讀 TASKS.md。
2. 把 RESUME-PROMPT.txt 的全文貼給家裡的 AI 助手，告訴它工作包或 Git checkout 的實際路徑。
3. 只閱讀或離線寫作可直接使用 project/。需要提交 GitHub 時，建議另 clone，避免把 ZIP 當成 Git checkout。

```sh
git clone https://github.com/t945935/-ai-diagramming-book.git
cd ./-ai-diagramming-book
git switch -c writing-foundations 5e1eb1addb738b70d2bc4093ae46de509ae9f5aa
make check-core
```

上面會從工作包的固定基準建立寫作分支。若家裡操作前遠端已有新工作，先比較並決定是否從最新 main 開始，不要覆蓋新提交。目錄名稱以連字號開頭，cd 必須保留 ./。

Windows 沒有 make 可從 project/ 或 checkout 根目錄執行：

```text
py -3 -m unittest discover -s tests -p test_graphviz_generator.py -v
py -3 -m unittest discover -s tests -p test_cross_tool_contract.py -v
py -3 -m unittest discover -s tests -p test_refund_change.py -v
```

Windows 命令是操作指引，未在 Windows 實測。打包後的核心測試是在本機 Linux 解壓副本上執行，結果見 VERIFICATION.txt。

## 工作包內容

- project/：原樣保存的已提交來源、預覽與文件。
- RESUME-PROMPT.txt：給新 AI 會話的上下文與下一步。
- TASKS.md：優先順序與驗收條件。
- ENVIRONMENT.md：工具前提與可攜性限制。
- MANIFEST.json：基準 commit、逐檔大小與 SHA-256。
- VERIFICATION.txt：從乾淨解壓副本執行核心檢查的實際輸出。

發布登入由家裡電腦自行授權。不要把密碼、token 或一次性驗證碼貼給 AI，也不要從舊電腦複製登入 JSON。
